from frappe import _

def get_data():
	return [
		{
			"module_name": "Oil Transfer",
			"type": "module",
			"label": _("Oil Transfer")
		}
	]
